var express = require('express');
var path = require('path');
var session = require('express-session');
var app = express();
var passport=require('passport');
var nodemailer = require('nodemailer');
const multer = require('multer');
const multer2 = require('multer');
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
var GitHubStrategy=require('passport-github').Strategy;









passport.use(new GitHubStrategy({
    clientID:"016fd53429b5b8477748",
    clientSecret:"3ef5ed1f4a844a4eccca5f9b1563b940deaac4b2",
    callbackURL:"http://localhost:3000/auth/github/callback"    
    },
    
    function(accessToken,refreshToken,profile,cb)
    {
    console.log("into");
    //User.findOrCreate({githubId:profile.id},function(err,user){
//       return cb(err,user); 
//    });
    return cb(err,profile); 
    }
    ));


app.get('/auth/github',passport.authenticate('github'));
app.get('/auth/github/callback',passport.authenticate('github',{failureRedirect:'/login.html'}),
       function(req,res){
    
    alert("succes");
    res.redirect('/');
});





//CORS


//app.use(function(req, res, next) {
//res.header('Access-Control-Allow-Credentials', true);
//res.header('Access-Control-Allow-Origin', req.headers.origin);
//res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
//res.header('Access-Control-Allow-Headers', 'X-Requested-With, X-HTTP-Method-Override, Content-Type, Accept');
//res.header("Access-Control-Allow-Credentials", "true");
//if ('OPTIONS' == req.method) {
//     res.send(200);
// } else {
//     next();
// }
//});

//var session = require('express-session');
//Acces static files
app.use(express.static(path.join(__dirname, 'public')));

//Bodyparser
app.use(express.urlencoded({extended: true})); 
app.use(express.json()); 
app.use(session({secret: "xYzUCAchitkara"}));
//Connect with db

var mongoose = require('mongoose');
var mongoDB = 'mongodb://localhost/myDB';

mongoose.connect(mongoDB);

mongoose.connection.on('error', (err) => {
    console.log('DB connection Error');
});

mongoose.connection.on('connected', (err) => {
    console.log('DB connected');
});

app.get('/userValidation' , (req,res)=>{
    if(req.session.email==undefined)
    res.redirect('/login.html');
else{
  res.render('userValidation');
}
})

app.get('/AddCommunity' , (req,res)=>{
    if(req.session.email==undefined)
    res.redirect('/login.html');
else{
  res.render('addCommunity');
}
})

app.get('/userHomePage' , (req,res)=>{
    if(req.session.email==undefined)
    res.redirect('/login.html');
else{
  res.render('userHomePage');
}
})
app.get('/comHomePage' , (req,res)=>{
    if(req.session.email==undefined)
    res.redirect('/login.html');
else{
  res.render('comHomePage');
}
})
app.get('/searchcom' , (req,res)=>{
    if(req.session.email==undefined)
    res.redirect('/login.html');
else{
  res.render('searchcom');
}
})
app.get('/comComPage' , (req,res)=>{
    if(req.session.email==undefined)
    res.redirect('/login.html');
else{
  res.render('comComPage');
}
})
app.get('/userpass' , (req,res)=>{
    if(req.session.email==undefined)
    res.redirect('/login.html');
else{
  res.render('userpass');}
})
app.get('/compass' , (req,res)=>{
    if(req.session.email==undefined)
    res.redirect('/login.html');
else{
  res.render('compass');}
})
app.get('/homepg' , (req,res)=>{
    console.log(req.session.email==undefined)
    if(req.session.email==undefined)
    res.redirect('/login.html');
else{
  res.render('homepg');}
})
app.get('/addUser' , (req,res)=>{
    if(req.session.email==undefined)
    res.redirect('/login.html');
else{
  res.render('addUser');}
})
app.get('/userList' , (req,res)=>{
    if(req.session.email==undefined)
    res.redirect('/login.html');
else{
  res.render('userList');}
})
app.get('/communityList' , (req,res)=>{
    if(req.session.email==undefined)
    res.redirect('/login.html');
else{
  res.render('communityList');}
})
app.get('/switchAsUser' , (req,res)=>{
    if(req.session.email==undefined)
    res.redirect('/login.html');
else{
  res.render('switchAsUser');
}
})
app.get('/tagPanel' , (req,res)=>{
    if(req.session.email==undefined)
    res.redirect('/login.html');
else{
  res.render('tagPanel');}
})
app.get('/changePassword' , (req,res)=>{
    if(req.session.email==undefined)
    res.redirect('/login.html');
else{
  res.render('changePassword');}
})
app.get('/logout' , (req,res)=>{
  res.render('logout');
})


app.get('/comdetails' , (req,res)=>{
    if(req.session.email==undefined)
    res.redirect('/login.html');
else{
  res.render('comdetails');
}
})

app.get('/responseowner' , (req,res)=>{
    if(req.session.email==undefined)
    res.redirect('/login.html');
else{
  res.render('responseowner');}
})

app.get('/comdetails2' , (req,res)=>{
    if(req.session.email==undefined)
    res.redirect('/login.html');
else{
  res.render('comdetails2');}
})
app.get('/comdetails3' , (req,res)=>{
    if(req.session.email==undefined)
    res.redirect('/login.html');
else{
  res.render('comdetails3');}
})






// Schema for product
var comSchema = new mongoose.Schema({
    name: String,
    email:String,
    date :String,
    desc:String,
    location:String,rule:String,
    active:String,
    pic:String,
    members:[],
    request:[]
  })

var coms=mongoose.model('coms',comSchema);

app.post('/CommunityData',function(req,res){
    var arr=[{email:req.session.email}]
    console.log(req.body);
    let newcom=new coms({
        
    name: req.body.name,
    email:req.session.email,
    date :req.body.date,
    desc:req.body.description,
    location:req.body.location ,
    rule:req.body.rule,
    active:0,    
    members:arr
    })
    newcom.save()
    .then(data=>{
        console.log(data);
      comid=data._id;
       comname=data.name;
        console.log("................................................");
        console.log(data);
        console.log(data._id);
        users.findOneAndUpdate({
            email:req.session.email  
          },
         {
             $push:{community:{'name':req.body.name,"status":'Owner'}}
          },{
          new: true,                       // return updated doc
          runValidators: true              // validate before update
        })
        .then(data=>{
           res.send("Saved"); 
        })
        .catch(err=>{
            res.send("error")
        })
        
    })
    .catch(err=>{
        console.log(err);
        res.send(err);
    })
    
    
    
});






app.post('/comsdata',(req,res)=>{
    
    coms.find({
        name:req.body.name
    })
    .then(data=>res.send(data))
    .catch(err=>res.send(err))
    
    
    
})













// Schema for product
var userSchema = new mongoose.Schema({
    name: String,
    password: String,
    email:String,
    phone :String,
    city:String,
    role:String,
    dob:String,
    status:String,
    active:String,
    gender:String,
    interest:String,
    journey:String,
    expectations:String,
    pic:String,
    pendingreq:[],
    community:[]
  })

var users=mongoose.model('users',userSchema);


//multer
const storage = multer.diskStorage({
  destination: './public/uploads/',
  filename: function(req, file, cb){
    cb(null,file.fieldname + '-' + req.session.email + path.extname(file.originalname));
  }
});

// Init Upload
const upload = multer({
  storage: storage,
  limits:{fileSize: 1000000},
  fileFilter: function(req, file, cb){
    checkFileType(file, cb);
  }
}).single('pic');

// Check File Type
function checkFileType(file, cb){
  // Allowed ext
  const filetypes = /jpeg|jpg|png|gif/;
  // Check ext
  const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
  // Check mime
  const mimetype = filetypes.test(file.mimetype);

  if(mimetype && extname){
    return cb(null,true);
  } else {
    cb('Error: Images Only!');
  }
}

app.post('/upload', (req, res) => {
  upload(req, res, (err) => {
     if(err){
      res.render('userValidation', {
        msg: err
      });
    } else {
      if(req.file == undefined){
        res.render('userValidation', {
          msg: 'Error: No File Selected!'
        });
      } else {
          users.findOneAndUpdate({
            email:req.session.email  
          },
         {
              pic:`uploads/${req.file.filename}`
          },{
      new: true,                       // return updated doc
      runValidators: true              // validate before update
    })
    .then(data => {
        console.log(data)
      })
      .catch(err => {
        console.error(err)
      })
        res.render('userValidation', {
          msg: 'File Uploaded!',
          file: `uploads/${req.file.filename}`
        });
      }
    }
    
  });
});







app.post('/getuserdata',(req,res)=>{
    
    users.find({
        email:req.body.email
    })
    .then(data=>res.send(data)).catch(err=>res.send(err))
    
    
    
})







function mail(userEmail,subj,message){
var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'brahmjit2411@gmail.com',
    pass: 'feelthegod'
  }
});

var mailOptions = {
  from: 'brahmjit2411@gmail.com',
  to: userEmail,
  subject:subj,
  html: '<html><body>'+ message+'</html></body>'
};

transporter.sendMail(mailOptions, function(error, info){
  if (error) {
    console.log(error);
  } else {
    console.log('Email sent: ' + info.response);
  }
});

    
    
}







app.post("/changep",(req,res)=>{
   users.find({
       email:req.session.email
   })
    .then(data=>{
       
   users.findOneAndUpdate(
    {
       email:req.session.email // search query
    }, 
    {
       password:req.body.newp// field:values to update
    },
    {
      new: true,                       // return updated doc
      runValidators: true              // validate before update
    })
    .then(data => {
        console.log(data)
        res.send("Saved")
      })
      .catch(err => {
        console.error(err)
        res.send("error")
      })
    
   })
    .catch(err=>{
       console.log(err);
   })
    
});








/////////////////////////////////////////////////////////////////////////////////















app.post('/acceptreq',(req,res)=>{
    
    console.log(req.body);
    var umail=req.body.umail;
    var omail=req.body.omail;
    var comname=req.body.comname;
    
    
    coms.findOneAndUpdate({
            name:comname 
          },
         {
             $pull:{request:{'email':umail}},
             $push:{members:{'email':umail}}
          },{
          new: true,                       // return updated doc
          runValidators: true              // validate before update
        })
        .then(data=>{
        
        
        
            users.findOneAndUpdate({
            email:umail,
                "community.name":comname
          },
         {
               
                $set:{"community.$.status":"Joined"}
          },{
          new: true,                       // return updated doc
          runValidators: true              // validate before update
        })
        .then(data=>{
          
                
                
                users.findOneAndUpdate({
                 email:omail 
                  },
                 {
                     $pull:{pendingreq:{$elemMatch:{'email':umail,'name':comname}}},
                     
                  },{
                  new: true,                       // return updated doc
                  runValidators: true              // validate before update
                })
                 .then(data=>res.send("Saved"))
                .catch(err=>{
                    console.log(err);res.send("Error")});
                
        })
        .catch(err=>{
                    console.log(err);res.send("Error")})
        
           
        
        
         
        })
        .catch(err=>{
                    console.log(err);res.send("Error")})
        
    
    
    
    
    
    
    
})







/////////////////////////////////////////


















////////////////////////////////////////////////////////////////////////////
var comid;
var comname;

//multer
const storagecom = multer2.diskStorage({
  destination: './public/uploads/community/',
  filename: function(req, file, cb){
      
    cb(null,file.fieldname + '-' + comid + path.extname(file.originalname));
  }
});

// Init Upload
const uploadcom = multer2({
  storage: storagecom,
  limits:{fileSize: 1000000},
  fileFilter: function(req, file, cb){
    checkFileType2(file, cb);
  }
}).single('pic');

// Check File Type
function checkFileType2(file, cb){
  // Allowed ext
  const filetypes = /jpeg|jpg|png|gif/;
  // Check ext
  const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
  // Check mime
  const mimetype = filetypes.test(file.mimetype);

  if(mimetype && extname){
    return cb(null,true);
  } else {
    cb('Error: Images Only!');
  }
}

app.post('/uploadComPic', (req, res) => {
    console.log("--------------------------,,,,,,,,,,,,,,,,,,,,,,,------------------");
    console.log(req.body);
    console.log("--------------------------,,,,,,,,,,,,,,,,,,,,,,,------------------");
  uploadcom(req, res, (err) => {
      
      
          console.log("-----------------------------------------------------------------------");
      console.log(req.file);
      
     if(err){
         res.render('addCommunity', {
        msg: err
      });
    } else {
      if(req.file == undefined){
        res.render('addCommunity', {
          msg: 'Error: No File Selected!'
        });
      } else {
          
          console.log("-----------------------------------------------------------------------");
          console.log(comname);
          console.log("-----------------------------------------------------------------------");
                      coms.findOneAndUpdate(
                   {
                   name:comname // search query
                    }, 
                   {
                   pic:`uploads/community/${req.file.filename}`
                   },
                   {
                  new: true,                       // return updated doc
                  runValidators: true              // validate before upd
                   })
                     .then(data => {
                       console.log(data)
                         
                      })
                     .catch(err => {
                      console.error(err)
                  })
          res.render('addCommunity', {
                          msg: 'File Uploaded!',
                          file: `uploads/community/${req.file.filename}`
                        });

                  }
                }
    
  });
});






///////////////////////////////////////////////////////////////////////////////







app.post('/joinin',(req,res)=>{
       
    
    var comunity=req.body.comname; 
    coms.findOneAndUpdate({
            name:comunity  
          },
         {
              $push:{members:{'email':req.session.email}}
          },{
      new: true,                       // return updated doc
      runValidators: true              // validate before update
    })
    .then(data => {
        coms.find({
            name:comunity
        })
        .then(data=>{
        var status='Joined';
        if(data[0].email==req.session.email)
            status='Owner';
         users.findOneAndUpdate({
            email:req.session.email  
          },
         {
              $push:{community:{'name':comunity,"status":status}}
          },{
      new: true,                       // return updated doc
      runValidators: true              // validate before update
        })
        .then(data => {
            console.log(data)
                 res.send("saved");
          })
          .catch(err => {
            console.error(err)
                 res.send("error");
                })
    
            })
        .catch(err=>{
            res.send("error");
        })
      })
      .catch(err => {
        console.error(err)
        res.send("error");
      })
    
    
    
    
    
    
    
    
    
    
    
    });



//////////////////////////////////////////////////////////////////////////////////



app.post('/askjoinin',(req,res)=>{
       
    
    var comunity=req.body.comname; 
    coms.findOneAndUpdate({
            name:comunity  
          },
         {
              $push:{request:{'email':req.session.email}}
          },{
      new: true,                       // return updated doc
      runValidators: true              // validate before update
    })
    .then(data => {
        console.log(data)
         users.findOneAndUpdate({
            email:req.session.email,
            
          },
         {
              $push:{community:{'name':comunity,"status":'Requested'}}
          },{
      new: true,                       // return updated doc
      runValidators: true              // validate before update
    })
    .then(data => {
        console.log(data)
              var rmail;
    coms.find({
        name:comunity
    })
    .then(data=>{
        rmail=data[0].email;
        
        users.findOneAndUpdate({
            email:rmail,
            
          },
         {
              $push:{pendingreq:{'name':comunity,"email":req.session.email}}
          },{
      new: true,                       // return updated doc
      runValidators: true              // validate before update
    })
    .then(data => {
        console.log(data)
            res.send("saved");
      })
      .catch(err => {
        console.error(err)
            res.send("error");
      })
        
    })
    
      })
      .catch(err => {
        console.error(err)
             res.send("error");
      })
      })
      .catch(err => {
        console.error(err)
        res.send("error");
      })
    
    
    
   
    
    
    
    
    
    });









///////////////////////////////////////////////////////////////////////////////







app.post('/getcommunitydata',(req,res)=>{
       
    
    var search=req.body.search;
    var findobj={'members.email':{'$ne':req.session.email},'request.email':{'$ne':req.session.email}};
    if(search!='')
        findobj["$or"]= [{
        "name":  { '$regex' : search, '$options' : 'i' }
    }, {
        "email":{ '$regex' : search, '$options' : 'i' }
    },{
        "desc": { '$regex' : search, '$options' : 'i' }
    }]
    else{
        delete findobj["$or"];
    }
        
    
    
    
    
    coms.find(findobj)
    .then(data=>res.send(data)).catch(err=>res.send(err));
    
    
    });
    
    




//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////











app.post('/data',(req,res)=>{
        console.log(req.body);
    var col=req.body.order[0].column;
    var dir=req.body.order[0].dir;
    var dataCol={
        0:"email",
        1:"phone",
        2:"city",
        3:"status",
        4:"role"
    }
    var dataDir={
        "asc":1,
        "desc":-1 
    }
    
    getdata(dataCol[col],dataDir[dir]);
    
    
//    
//    var length;
//    users.find(findobj).then(data=>length=data.length).catch(err=>console.log(err));

function getdata(colname,sortorder)
{
    var numberOfUsers
     var x=users.count({},function(err,count){
         console.log('number of users :'+count);
         numberOfUsers=count;
     });
    var start=req.body.start;
    var length=req.body.length;
    var role=req.body.role;
    var status=req.body.status;
    var search=req.body.search.value;
    var active=req.body.active;    var findobj={};
    console.log(role,status);
    if(active!="All")
       { findobj.active=active;}
    else{
        delete findobj["active"];
    }
    if(role!="All")
       { findobj.role=role;}
    else{
        delete findobj["role"];
    }
    if(status!="All")
        {findobj.status=status;}
    else{
        delete findobj["status"];
    }
    if(search!='')
        findobj["$or"]= [{
        "email":  { '$regex' : search, '$options' : 'i' }
    }, {
        "phone":{ '$regex' : search, '$options' : 'i' }
    },{
        "city": { '$regex' : search, '$options' : 'i' }
    },{
        "status":  { '$regex' : search, '$options' : 'i' }
    },{
        "role": { '$regex' : search, '$options' : 'i' }
    }]
    else{
        delete findobj["$or"];
    }
                
    
    console.log("000000000000000000000000000000000000");
    console.log(findobj);
    console.log("000000000000000000000000000000000000");
    var length;
    users.find(findobj).then(data=>length=data.length).catch(err=>console.log(err));
    users.find(findobj).skip(parseInt(start)).limit(parseInt(length)).sort({[colname] : sortorder})
    .then(data => {
          res.send({
         "recordsTotal":String(numberOfUsers),
         "recordsFiltered":length,
         "start":parseInt(start),
         "length":parseInt(length),data})
   })
   .catch(err => {
     console.error(err)
     res.send("error getting info ")
   });
}





});











app.post("/sendmail",(req,res)=>{
    var email=req.body.email;
    var subject=req.body.subject;
    var body=req.body.body;
    mail(email,subject,body);
    res.send("Saved");
    
    
});














app.post('/comdata',(req,res)=>{
    
  var col=req.body.order[0].column;
    var dir=req.body.order[0].dir;
    var dataCol={
        0:"name",
        1:"rule",
        2:"location",
        3:"email",
        4:"date"  
    }
    var dataDir={
        "asc":1,
        "desc":-1 
    }
    
    var numberOfUsers
     var x=coms.count({},function(err,count){
         console.log('number of users :'+count);
         numberOfUsers=count;
     });
    var start=req.body.start;
    var length=req.body.length;
    var search=req.body.search.value;
    var rule=req.body.rule;
    
    var findobj={};
//    console.log(role,status);
    if(rule!='All')
        {
            findobj.rule=rule;
        }
    else{
        delete findobj["rule"];
    }
    if(search!='')
        findobj["$or"]= [{
        "name":  { '$regex' : search, '$options' : 'i' }
    }, {
        "email":{ '$regex' : search, '$options' : 'i' }
    },{
        "rule": { '$regex' : search, '$options' : 'i' }
    },{
        "location":  { '$regex' : search, '$options' : 'i' }
    }]
    else{
        delete findobj["$or"];
    }
                
    
    console.log("000000000000000000000000000000000000");
    console.log(findobj);
    console.log("000000000000000000000000000000000000");
    var length;
    coms.find(findobj).then(data=>length=data.length).catch(err=>console.log(err));
    coms.find(findobj).skip(parseInt(start)).limit(parseInt(length)).sort({[dataCol[col]] : dataDir[dir]})
    .then(data => {
          res.send({
         "recordsTotal":String(numberOfUsers),
         "recordsFiltered":length,
         "start":parseInt(start),
         "length":parseInt(length),data})
   })
   .catch(err => {
     console.error(err)
     res.send("error getting info ")
   });






});




app.post('/comalldata',(req,res)=>{
    
    coms.find({
        name:comname_pg
    })
    .then(data=>res.send(data))
    .catch(err=>res.send("error"))
    
    
});
var comname_pg;

app.post('/comname',(req,res)=>{
    
    comname_pg=req.body.name;
    console.log(comname_pg);
    res.send('Saved');
});






app.post('/comalldata3',(req,res)=>{
    
    coms.find({
        name:comname_pg3
    })
    .then(data=>res.send(data))
    .catch(err=>res.send("error"))
    
    
});
var comname_pg3;

app.post('/comname3',(req,res)=>{
    comname_pg3=req.body.name;
    console.log(comname_pg);
    res.send('Saved');
});


app.post('/comalldata2',(req,res)=>{
    
    coms.find({
        name:req.body.name
    })
    .then(data=>res.send(data))
    .catch(err=>res.send("error"))
    
    
});


















app.post("/deactivate",(req,res)=>{
   users.findOneAndUpdate(
    {
       email:req.body.email // search query
    }, 
    {
       active:req.body.active// field:values to update
    },
    {
      new: true,                       // return updated doc
      runValidators: true              // validate before update
    })
    .then(data => {
        console.log(data)
        res.send("Saved")
      })
      .catch(err => {
        console.error(err)
        res.send("error")
      })
    
    
});
























app.post('/',function(req,res){
  
     users.find({
         // search query
         email: req.body.email,
         password:req.body.password
    })
    .then(data => {
        console.log(data)
         if(data!="")
         {
             req.session.email = req.body.email;
             console.log(data[0].role,data[0].status);
             if(data[0].role==="User" && data[0].status=="Confirmed")
             res.send("USR1");
             else if(data[0].role==="User" && data[0].status=="Pending")
             res.send("USR0");
             else if(data[0].role==="Admin")
             res.send("ADM");
             else if(data[0].role==="Commuity Builder"&& data[0].status=="Pending")
             res.send("COM0");
             else if(data[0].role==="Commuity Builder"&& data[0].status=="Confirmed")
             res.send("COM1");
             else{
                 res.send("notworking22");
             }
         }
         else
             res.send("notworking")
      })
      .catch(err => {
        console.error(err)
        res.send("notworking")
      }) 
    
});

//giving user data;
app.get('/userData',(req,res)=>{
     console.log(req.session);
    users.find({
     'email':req.session.email
    })
   
     .then(data => {
     console.log(data)
     res.send(data)
   })
   .catch(err => {
     console.error(err)
     res.send("error getting info ")
   });
})    
    

//giving all data;
app.get('/allData',(req,res)=>{
     console.log(req.session);
    users.find({
    })
     .then(data => {
     console.log(data.length);
        var data2={};
        for(var i=0;i<10;i++)
            data2[i]=data[i];
        data2.length=10;
        console.log(data2);
     res.send(data2)
   })
   .catch(err => {
     console.error(err)
     res.send("error getting info ")
   });
})    
    



var welcomeMsg="Thanks for Joining CQ";

//adding user data
app.post('/user_add',function (req, res) {
  console.log(req.body);
  let newUser = new users({
     name: req.body.name,
    password: req.body.password,
    email:req.body.email,
    phone :req.body.phone,
    city:req.body.city,
    role:req.body.role,
      dob:"NOT-SET",
      status:"Pending",
      active:"1"
  })
  newUser.save()
   .then(data => {
     console.log(data)
      mail(req.body.email,"CQ",welcomeMsg);
     res.send("Saved")
   })
   .catch(err => {
     console.error(err)
     res.send("error")
   });
  
});





//updating user data

app.put('/updateUser',function(req,res){
    console.log(req.body);
    users.findOneAndUpdate(
    {
       email:req.body.email // search query
    }, 
    {
       email:req.body.emailNew,
       phone :req.body.phoneNew,
       city:req.body.cityNew,
       role:req.body.roleNew,
        status:req.body.statusNew// field:values to update
    },
    {
      new: true,                       // return updated doc
      runValidators: true              // validate before update
    })
    .then(data => {
        console.log(data)
        res.send("Saved")
      })
      .catch(err => {
        console.error(err)
        res.send("error")
      })
})





app.put('/updateCom',function(req,res){
    console.log(req.body)
    coms.findOneAndUpdate(
    {
       name:req.body.name // search query
    }, 
    {
       name:req.body.nameNew,
        active:req.body.activeNew// field:values to update
    },
    {
      new: true,                       // return updated doc
      runValidators: true              // validate before update
    })
    .then(data => {
        console.log(data)
        res.send("Saved")
      })
      .catch(err => {
        console.error(err)
        res.send("error")
      })
})




app.get('/logout', function(req, res) {
  if (req.session) {
    // delete session object
    req.session.destroy();
      res.send("/login");
  }
     
});






app.post('/updateUserData',function(req,res){
    
     users.findOneAndUpdate(
    {
       email:req.body.email // search query
    }, 
    {
       email:req.body.email,
       name :req.body.name,
       city:req.body.city,
       gender:req.body.gender,
       dob:req.body.dob,// field:values to update
        phone:req.body.phone,
        interest:req.body.interest,
        journey:req.body.journey,
        expectations:req.body.expectations,
        status:"Confirmed"
        
    },
    {
      new: true,                       // return updated doc
      runValidators: true              // validate before update
    })
    .then(data => {
        console.log(data)
        res.send("Saved")
      })
      .catch(err => {
        console.error(err)
        res.send("error")
      })
    
    
});




















app.listen(3000)
