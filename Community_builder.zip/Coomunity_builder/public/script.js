var sbtn=document.getElementById("sbtn");
var pass=document.getElementById("pass");
var email_=document.getElementById("email");
var git_btn=document.getElementById("git-btn");
sbtn.addEventListener("click",function(event){
    chkit();
    pason();    
});

function chkit()
{
    var password=pass.value;
    var email=email_.value;
    if(password==""||email=="")
        alert("Enter Values!");
}
function pason()
{
    var req=new XMLHttpRequest();
    req.addEventListener("load",function(){
        console.log(req.responseText);
        if(req.responseText=="notworking")
            {
                alert("-_-");
                               
            }
        else {
             alert("OK");
          
            
              if(req.responseText==="USR0")
                    window.location='/userValidation';
             else if(req.responseText==="USR1")
                    window.location='/userHomePage';
            else  if(req.responseText==="COM0")
                    window.location='/userValidation';
             else if(req.responseText==="COM1")
                    window.location='/comHomePage';
                else if(req.responseText=="ADM"){
                window.location='/homepg';
                }
            else{
                alert("Not-Yet");
            }
        }
        
    });
    req.open("POST",'/');
    console.log(email_.value);
    console.log(pass.value);
    req.setRequestHeader('Content-Type','application/json');
    req.send(JSON.stringify({'email':email_.value,'password':pass.value}));
    
}


function logon()
{
    var xhr =  new XMLHttpRequest();
    xhr.withCredentials = true;
  xhr.addEventListener("load",function()
{
  if(xhr.readyState === 4 && xhr.status ===200)
  {
    var data = JSON.parse(xhr.responseText);
    console.log(data);
  }
});
  xhr.open('GET','/auth/github');
  xhr.send();
    
    
}
